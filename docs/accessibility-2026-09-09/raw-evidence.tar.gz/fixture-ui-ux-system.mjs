import { expect } from '/home/julian/Documents/CodeCollective/portal/web/node_modules/@playwright/test/index.mjs';
const authUser = {
    id: 'test-user-1',
    email: 'mobile@test.org',
    full_name: 'Mobile Tester',
    avatar_url: 'https://assets.test/mobile-tester.png',
    identity_data: {
        display_name: 'Mobile Tester',
        bio: 'Testing public identity and chat flows.',
        avatar_url: 'https://assets.test/mobile-tester.png',
        first_name: 'Mobile',
        last_name: 'Tester',
    },
};
const contactPage = {
    user_id: 'test-user-1',
    user_name: 'Mobile Tester',
    slug: 'mobile-tester',
    enabled: true,
    headline: 'Civic systems tester',
    bio: 'Testing public identity and chat flows.',
    photo_url: 'https://assets.test/mobile-tester.png',
    email_public: 'mobile@test.org',
    phone_public: '+15551234567',
    website_url: 'https://codecollective.us',
    linkedin_url: 'https://linkedin.test/mobile',
    github_url: 'https://github.test/mobile',
    x_url: 'https://x.test/mobile',
    links: [
        { label: 'Calendar', url: 'https://calendar.test/mobile' },
        { label: 'Office Hours', url: 'https://meet.test/mobile' },
    ],
    public_url: 'http://127.0.0.1:4173/users/mobile-tester',
};
const otherContactPage = {
    ...contactPage,
    user_id: 'test-user-2',
    user_name: 'Jordan Contact',
    slug: 'jordan-contact',
    headline: 'Community organizer',
    email_public: 'jordan@test.org',
    public_url: 'http://127.0.0.1:4173/users/jordan-contact',
};
async function fulfillJson(route, body, status = 200) {
    await route.fulfill({
        status,
        contentType: 'application/json',
        body: JSON.stringify(body),
    });
}
async function mockCommon(page) {
    await page.route('**/assets.test/**', async (route) => {
        await route.fulfill({
            status: 200,
            contentType: 'image/png',
            body: Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==', 'base64'),
        });
    });
    await page.route('**/auth/session-token', async (route) => {
        await fulfillJson(route, { access_token: 'header.payload.signature' });
    });
    await page.route('**/auth/me', async (route) => {
        if (route.request().method() === 'PUT') {
            const body = JSON.parse(route.request().postData() || '{}');
            await fulfillJson(route, {
                id: authUser.id,
                email: authUser.email,
                full_name: body.full_name || authUser.full_name,
                avatar_url: body.avatar_url || authUser.avatar_url,
                identity_data: body,
            });
            return;
        }
        await fulfillJson(route, authUser);
    });
    await page.route('**/api/org/admin/me', async (route) => {
        await fulfillJson(route, { is_sysadmin: false });
    });
    await page.route('**/api/org/api/network/orgs?mine=true**', async (route) => {
        await fulfillJson(route, [
            { id: 'org-1', name: 'Code Collective', slug: 'code-collective', my_role: 'admin', claimed_by_user_id: authUser.id },
        ]);
    });
    await page.route('**/api/org/api/network/orgs/public?**', async (route) => {
        await fulfillJson(route, [
            {
                id: 'org-2',
                name: 'Neighborhood Assembly',
                slug: 'neighborhood-assembly',
                description: 'A larger public organization.',
                image_url: null,
                membership_count: 200,
                upcoming_events_count: 3,
                pending_claim_requests_count: 0,
                is_contested: false,
            },
            {
                id: 'org-1',
                name: 'Code Collective',
                slug: 'code-collective',
                description: 'The organization this user belongs to.',
                image_url: null,
                membership_count: 1,
                upcoming_events_count: 0,
                pending_claim_requests_count: 0,
                is_contested: false,
            },
        ]);
    });
    await page.route('**/api/org/api/network/orgs/public/**', async (route) => {
        await fulfillJson(route, { is_contested: false, pending_claim_requests_count: 0 });
    });
    await page.route('**/api/org/api/network/users/public/mobile-tester/events**', async (route) => {
        await fulfillJson(route, []);
    });
    await page.route('**/api/org/api/network/users/public/jordan-contact/events**', async (route) => {
        await fulfillJson(route, []);
    });
    await page.route('**/api/org/api/network/users/public/mobile-tester', async (route) => {
        await fulfillJson(route, contactPage);
    });
    await page.route('**/api/org/api/network/users/public/jordan-contact', async (route) => {
        await fulfillJson(route, otherContactPage);
    });
    await page.route('**/api/org/api/network/contact/me', async (route) => {
        if (route.request().method() === 'PUT') {
            await fulfillJson(route, { ...contactPage, ...JSON.parse(route.request().postData() || '{}') });
            return;
        }
        await fulfillJson(route, contactPage);
    });
}
async function mockNativeChat(page, options = {}) {
    const conversation = {
        id: 'dm-1',
        kind: 'dm',
        title: null,
        updated_at: '2026-06-07T20:00:00.000Z',
        last_message_at: '2026-06-07T20:00:00.000Z',
        unread_count: 0,
        members: [
            { user_id: authUser.id, user_name: 'Mobile Tester', role: 'member', state: 'active' },
            { user_id: 'test-user-2', user_name: 'Jordan Contact', role: 'member', state: 'active' },
        ],
    };
    const initialMessages = [
        {
            id: 'msg-1',
            conversation_id: 'dm-1',
            sender_user_id: 'test-user-2',
            sender_name: 'Jordan Contact',
            client_message_id: 'seed-1',
            body: 'Existing hello from Jordan',
            message_type: 'text',
            created_at: '2026-06-07T20:00:00.000Z',
            sequence: 1,
        },
    ];
    await page.route('**/api/network/chat/**', async (route) => {
        const request = route.request();
        const url = new URL(request.url());
        if (options.unauthorized) {
            await fulfillJson(route, { detail: 'Invalid credentials' }, 401);
            return;
        }
        if (url.pathname.endsWith('/api/network/chat/conversations') && request.method() === 'GET') {
            await fulfillJson(route, { conversations: [conversation] });
            return;
        }
        if (url.pathname.endsWith('/api/network/chat/dm') && request.method() === 'POST') {
            options.onStartDm?.(JSON.parse(request.postData() || '{}'));
            await fulfillJson(route, { conversation });
            return;
        }
        if (url.pathname.endsWith('/api/network/chat/conversations/dm-1/messages') && request.method() === 'GET') {
            await fulfillJson(route, { latest_sequence: 1, messages: initialMessages });
            return;
        }
        if (url.pathname.endsWith('/api/network/chat/conversations/dm-1/messages') && request.method() === 'POST') {
            if (options.failSend) {
                await fulfillJson(route, { detail: 'Message service unavailable' }, 503);
                return;
            }
            const body = JSON.parse(request.postData() || '{}');
            await fulfillJson(route, {
                message: {
                    id: 'msg-2',
                    conversation_id: 'dm-1',
                    sender_user_id: authUser.id,
                    sender_name: 'Mobile Tester',
                    client_message_id: body.client_message_id,
                    body: body.body,
                    message_type: 'text',
                    created_at: '2026-06-07T20:01:00.000Z',
                    sequence: 2,
                },
            });
            return;
        }
        if (url.pathname.endsWith('/api/network/chat/conversations/dm-1/sync')) {
            await fulfillJson(route, { conversation_id: 'dm-1', latest_sequence: 1, messages: [], receipts: [] });
            return;
        }
        if (url.pathname.endsWith('/api/network/chat/conversations/dm-1/read')) {
            await fulfillJson(route, { ok: true });
            return;
        }
        await fulfillJson(route, { detail: 'Unhandled chat mock route' }, 404);
    });
}
async function expectNoHorizontalOverflow(page) {
    const overflow = await page.evaluate(() => {
        const doc = document.documentElement;
        return { scrollWidth: doc.scrollWidth, clientWidth: doc.clientWidth, delta: doc.scrollWidth - doc.clientWidth };
    });
    expect(overflow.delta, `horizontal overflow: ${JSON.stringify(overflow)}`).toBeLessThanOrEqual(1);
}
async function expectInteractiveElementsHaveNames(page) {
    const unnamed = await page.evaluate(() => {
        function textAlternative(element) {
            const aria = element.getAttribute('aria-label') || element.getAttribute('title') || '';
            const text = element.textContent || '';
            const labelledBy = element.getAttribute('aria-labelledby');
            const labelledText = labelledBy
                ? labelledBy
                    .split(/\s+/)
                    .map((id) => document.getElementById(id)?.textContent || '')
                    .join(' ')
                : '';
            return `${aria} ${text} ${labelledText}`.trim();
        }
        return Array.from(document.querySelectorAll('a, button, input, textarea, select'))
            .filter((element) => {
            if (element.hasAttribute('disabled'))
                return false;
            if (element instanceof HTMLInputElement && element.type === 'hidden')
                return false;
            if (element instanceof HTMLInputElement) {
                const label = element.labels?.[0]?.textContent || '';
                return !`${textAlternative(element)} ${label} ${element.placeholder || ''}`.trim();
            }
            if (element instanceof HTMLTextAreaElement) {
                const label = element.labels?.[0]?.textContent || '';
                return !`${textAlternative(element)} ${label} ${element.placeholder || ''}`.trim();
            }
            return !textAlternative(element);
        })
            .map((element) => element.outerHTML.slice(0, 180));
    });
    expect(unnamed).toEqual([]);
}
export { mockCommon, mockNativeChat };
