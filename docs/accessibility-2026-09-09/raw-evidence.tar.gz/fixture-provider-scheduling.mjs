import { expect } from '/home/julian/Documents/CodeCollective/portal/web/node_modules/@playwright/test/index.mjs';
const authUser = { id: 'provider-current', email: 'provider@example.test', full_name: 'Current Provider' };
async function json(route, body, status = 200) {
    await route.fulfill({ status, contentType: 'application/json', body: JSON.stringify(body) });
}
async function mockProviderScheduling(page) {
    let providerDashboard = {
        services: [{
                id: 'provider-service-1',
                name: 'Half-hour session',
                description: 'Book a 30-minute session through the provider portal.',
                timezone: 'UTC',
                slot_minutes: 30,
                available_to_all: true,
                host_type: 'individual',
                host_user_id: authUser.id,
                host_user_name: authUser.full_name,
                host_org_id: null,
                host_org_name: null,
                google_calendar_sync: true,
                google_block_busy: true,
                hours: [
                    { weekday: 1, starts_at: '14:00', ends_at: '17:00' },
                    { weekday: 2, starts_at: '14:00', ends_at: '17:00' },
                    { weekday: 3, starts_at: '14:00', ends_at: '17:00' },
                    { weekday: 4, starts_at: '14:00', ends_at: '17:00' },
                    { weekday: 5, starts_at: '14:00', ends_at: '17:00' },
                ],
            }],
        appointments: [{
                id: 'appointment-1',
                service_id: 'provider-service-1',
                service_name: 'Half-hour session',
                starts_at: '2026-08-12T14:00:00.000Z',
                ends_at: '2026-08-12T14:30:00.000Z',
                status: 'requested',
                attendee_user_id: 'member-2',
                attendee_name: 'Jordan Booker',
                attendee_email: 'jordan@example.test',
            }],
    };
    let googleCalendar = {
        connected: true,
        google_email: 'provider@gmail.test',
        calendar_id: 'primary',
        sync_busy: true,
        updated_at: '2026-08-11T12:00:00.000Z',
    };
    await page.route('**/api/org/**', (route) => json(route, {}));
    await page.route('**/auth/session-token', (route) => json(route, { access_token: 'header.payload.signature' }));
    await page.route('**/auth/me', (route) => json(route, authUser));
    await page.route('**/api/org/admin/me', (route) => json(route, { is_sysadmin: false }));
    await page.route('**/auth/google-calendar', async (route) => {
        if (route.request().method() === 'GET')
            return json(route, googleCalendar);
        if (route.request().method() === 'DELETE') {
            googleCalendar = { ...googleCalendar, connected: false, google_email: null, calendar_id: null, sync_busy: false, updated_at: '2026-08-11T12:30:00.000Z' };
            providerDashboard = {
                ...providerDashboard,
                services: providerDashboard.services.map((service) => ({
                    ...service,
                    google_calendar_sync: false,
                    google_block_busy: false,
                })),
            };
            return json(route, { ok: true });
        }
        return route.fallback();
    });
    await page.route('**/api/org/api/network/orgs?**', (route) => json(route, [
        { id: 'org-1', name: 'Care Collective', slug: 'care-collective', my_role: 'owner' },
    ]));
    await page.route('**/api/org/api/health-insurance/provider', async (route) => json(route, providerDashboard));
    await page.route('**/api/org/api/health-insurance/services', async (route) => {
        const payload = JSON.parse(route.request().postData() || '{}');
        expect(payload).toMatchObject({
            host_type: 'individual',
            name: 'Weekday consult',
            timezone: 'UTC',
            slot_minutes: 30,
            capacity_per_slot: 1,
            weekdays: [1, 2, 3, 4, 5],
            starts_at: '14:00',
            ends_at: '17:00',
            google_calendar_sync: true,
            google_block_busy: true,
        });
        providerDashboard = {
            ...providerDashboard,
            services: [
                ...providerDashboard.services,
                {
                    id: 'provider-service-2',
                    description: payload.description,
                    available_to_all: true,
                    host_user_id: authUser.id,
                    host_user_name: authUser.full_name,
                    host_org_id: null,
                    host_org_name: null,
                    ...payload,
                    slot_minutes: 30,
                    hours: payload.weekdays.map((weekday) => ({ weekday, starts_at: payload.starts_at, ends_at: payload.ends_at })),
                },
            ],
        };
        await json(route, { id: 'provider-service-2', ...payload }, 201);
    });
}
export { mockProviderScheduling };
