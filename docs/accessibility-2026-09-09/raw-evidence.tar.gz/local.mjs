import { chromium } from '/home/julian/Documents/CodeCollective/portal/web/node_modules/playwright/index.mjs';
import ts from '/home/julian/Documents/CodeCollective/portal/web/node_modules/typescript/lib/typescript.js';
import fs from 'node:fs/promises';
const root='/home/julian/Documents/CodeCollective/portal/web',out='/tmp/portal-accessibility-2026-09-09';
const fixtureSpecs=[['ui-ux-system',['mockCommon','mockNativeChat']],['health-insurance',['mockHealthProgram']],['provider-scheduling',['mockProviderScheduling']],['life-insurance',['mockAuthenticatedProgram']],['property-casualty-insurance',['mockAuthenticatedPortal']],['user-calendar',['mockCalendarMember']]];
const fixture={};
for(const [name,exports] of fixtureSpecs){
 let src=await fs.readFile(root+'/tests/e2e/'+name+'.spec.ts','utf8');src=src.split(/\ntest(?:\(|\.describe)/)[0]+`\nexport { ${exports.join(',')} };`;
 src=src.replace("from '@playwright/test'",`from '${root}/node_modules/@playwright/test/index.mjs'`);
 await fs.writeFile(out+'/fixture-'+name+'.mjs',ts.transpileModule(src,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText);
 Object.assign(fixture,await import(out+'/fixture-'+name+'.mjs'));
}
const browser=await chromium.launch({headless:true});const results=[];
async function setup(theme='light',authenticated=true){
 const context=await browser.newContext({viewport:{width:1440,height:1000},colorScheme:theme});
 await context.addInitScript(t=>localStorage.setItem('orgportal.theme',t),theme);
 await context.route('**/*',async route=>{const u=new URL(route.request().url());
  if(u.pathname.startsWith('/auth/')||u.pathname.startsWith('/pidp/')||u.pathname.startsWith('/api/'))return route.fulfill({status:authenticated?200:401,contentType:'application/json',body:JSON.stringify(authenticated?{}:{detail:'Not signed in'})});
  if(u.hostname!=='127.0.0.1')return route.abort();
  if(!['GET','HEAD','OPTIONS'].includes(route.request().method()))return route.abort();
  return route.continue();
 });
 const page=await context.newPage();if(authenticated)await fixture.mockCommon(page);return {context,page};
}
async function record(page,id){
 await page.addScriptTag({path:out+'/axe.min.js'});const ax=await page.evaluate(async()=>{const r=await axe.run(document,{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21a','wcag21aa','wcag22aa','best-practice']}});return {version:r.testEngine.version,violations:r.violations,passes:r.passes.map(x=>x.id),incomplete:r.incomplete.map(x=>({id:x.id,nodes:x.nodes.length}))};});
 const result={id,url:page.url(),title:await page.title(),axe:ax,desktop:await dom(page)};
 await page.screenshot({path:out+'/local-'+id+'.png'});
 await page.setViewportSize({width:320,height:900});await page.waitForTimeout(100);result.narrow=await dom(page);
 if(result.narrow.overflow>1)await page.screenshot({path:out+'/local-'+id+'-320.png'});
 results.push(result);await fs.writeFile(out+'/local-results.json',JSON.stringify(results,null,2));console.log(JSON.stringify({id,violations:ax.violations.map(v=>({id:v.id,n:v.nodes.length})),overflow:result.narrow.overflow}));return result;
}
async function dom(page){return page.evaluate(()=>({overflow:document.documentElement.scrollWidth-innerWidth,headings:[...document.querySelectorAll('h1,h2,h3')].map(e=>({tag:e.tagName,text:e.textContent.trim()})),body:document.querySelector('main')?.innerText.slice(0,900),fields:[...document.querySelectorAll('input,select,textarea')].map(e=>({tag:e.tagName,type:e.type,id:e.id,label:[...e.labels||[]].map(x=>x.textContent.trim()).join(' '),ariaLabel:e.getAttribute('aria-label'),autocomplete:e.autocomplete})),overflowElements:[...document.querySelectorAll('main *')].filter(e=>e.getBoundingClientRect().right>innerWidth+1).slice(0,10).map(e=>({tag:e.tagName,class:e.className,right:e.getBoundingClientRect().right,text:e.textContent.slice(0,50)}))}));}
const pages=[['profile',null],['settings',null],['id',null],['chat/dm-1','mockNativeChat'],['health-insurance','mockHealthProgram'],['provider-scheduling','mockProviderScheduling'],['life-insurance','mockAuthenticatedProgram'],['property-casualty-insurance','mockAuthenticatedPortal'],['calendar','mockCalendarMember']];
const jobs=pages.flatMap(([route,mock])=>['light','dark'].map(theme=>({route,mock,theme})));
await Promise.all([0,1].map(async()=>{while(jobs.length){const {route,mock,theme}=jobs.shift();const {context,page}=await setup(theme);const errors=[];page.on('pageerror',e=>errors.push(e.message));try{if(mock)await fixture[mock](page);await page.route('**/api/timebank/community',r=>r.fulfill({status:200,contentType:'application/json',body:'{"id":"code-collective","name":"Code Collective"}'}));await page.goto('http://127.0.0.1:4197/'+route);await page.waitForSelector('main',{timeout:15000});await page.waitForTimeout(900);if(await page.getByText('Unexpected Application Error!',{exact:true}).count())throw new Error(errors.join('; '));await record(page,route.replaceAll('/','_')+'-'+theme);}catch(e){console.log(JSON.stringify({route,error:String(e),errors}));}await context.close();}}));
await fs.writeFile(out+'/local-results.json',JSON.stringify(results,null,2));
await browser.close();
