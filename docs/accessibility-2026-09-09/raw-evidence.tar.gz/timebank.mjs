import {chromium} from '/home/julian/Documents/CodeCollective/portal/web/node_modules/playwright/index.mjs';
import {mockCommon,mockNativeChat} from './fixture-ui-ux-system.mjs';
import fs from 'node:fs/promises';
const out='/tmp/portal-accessibility-2026-09-09',browser=await chromium.launch(),results=[];
for(const theme of ['light','dark']){
 const context=await browser.newContext({viewport:{width:1280,height:900},colorScheme:theme});
 await context.addInitScript(t=>localStorage.setItem('orgportal.theme',t),theme);
 await context.route('**/*',r=>{const u=new URL(r.request().url());if(u.pathname.startsWith('/api/')||u.pathname.startsWith('/pidp/')||u.pathname.startsWith('/auth/'))return r.fulfill({status:401,contentType:'application/json',body:'{}'});if(u.hostname!=='127.0.0.1')return r.abort();return r.continue();});
 const page=await context.newPage();await mockCommon(page);await mockNativeChat(page);
 const community={id:'code-collective',hostname:'codecollective.us',name:'Code Collective',tagline:'Community timebank',accent_color:'#18745b'};
 await page.route('**/api/timebank**',r=>{const u=new URL(r.request().url());let body={};if(u.pathname.endsWith('/community'))body=community;else if(u.pathname.endsWith('/notifications'))body={items:[],unread_count:0,next_cursor:null};else body={account:{user_id:'test-user-1',balance_minutes:0,earned_minutes:0,spent_minutes:0},listings:[],exchanges:[],community,can_manage_community:false};return r.fulfill({status:200,contentType:'application/json',body:JSON.stringify(body)});});
 await page.goto('http://127.0.0.1:4197/timebanking');await page.getByRole('button',{name:'Add offer',exact:true}).waitFor();await page.addScriptTag({path:out+'/axe.min.js'});
 const scan=()=>page.evaluate(async()=>{const r=await axe.run(document,{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21a','wcag21aa','wcag22aa','best-practice']}});return {violations:r.violations,incomplete:r.incomplete.map(v=>({id:v.id,n:v.nodes.length}))};});
 const result={theme,default:await scan()};await page.setViewportSize({width:320,height:900});result.overflow=await page.evaluate(()=>document.documentElement.scrollWidth-innerWidth);result.mobile=await scan();
 await page.getByRole('button',{name:'Add offer',exact:true}).focus();await page.keyboard.press('Enter');await page.getByRole('dialog').waitFor();result.dialog=await scan();result.focusInside=await page.evaluate(()=>!!document.activeElement.closest('dialog'));await page.keyboard.press('Escape');result.closed=await page.getByRole('dialog').count()===0;result.restoredFocus=await page.evaluate(()=>document.activeElement.getAttribute('aria-label'));await page.screenshot({path:out+'/timebank-'+theme+'-320.png'});results.push(result);await context.close();
}
await fs.writeFile(out+'/timebank-results.json',JSON.stringify(results,null,2));console.log(JSON.stringify(results,(k,v)=>['default','mobile','dialog'].includes(k)?v.violations.map(x=>({id:x.id,n:x.nodes.length})):v,2));await browser.close();
