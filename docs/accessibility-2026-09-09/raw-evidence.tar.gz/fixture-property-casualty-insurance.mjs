const authUser = {
    id: 'member-current',
    email: 'member@example.test',
    full_name: 'Current Member',
    identity_data: { display_name: 'Current Member' },
};
async function json(route, body, status = 200) {
    await route.fulfill({ status, contentType: 'application/json', body: JSON.stringify(body) });
}
async function mockAuthenticatedPortal(page) {
    await page.route('**/api/org/**', (route) => json(route, {}));
    await page.route('**/auth/session-token', (route) => json(route, { access_token: 'header.payload.signature' }));
    await page.route('**/auth/me', (route) => json(route, authUser));
    await page.route('**/api/org/admin/me', (route) => json(route, { is_sysadmin: false }));
}
export { mockAuthenticatedPortal };
