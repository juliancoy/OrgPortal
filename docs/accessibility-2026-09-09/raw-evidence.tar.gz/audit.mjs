import { chromium } from '/home/julian/Documents/CodeCollective/portal/web/node_modules/playwright/index.mjs';
import fs from 'node:fs/promises';
const out='/tmp/portal-accessibility-2026-09-09';
const browser=await chromium.launch({headless:true});
const routes=['/','/users/login','/users/register','/about','/people','/orgs','/events','/search','/finance','/departments','/create','/orgs/register','/governance','/governance/propose'];
const jobs=routes.flatMap(route=>['light','dark'].map(theme=>({route,theme,base:'https://codecollective.us/p',kind:'production'})));
const results=[];
async function scan(job){
 const context=await browser.newContext({viewport:{width:1440,height:1000},colorScheme:job.theme});
 await context.addInitScript(theme=>localStorage.setItem('orgportal.theme',theme),job.theme);
 await context.route('**/*',route=>['GET','HEAD','OPTIONS'].includes(route.request().method())?route.continue():route.abort());
 const page=await context.newPage(); const errors=[];page.on('pageerror',e=>errors.push(e.message));
 const result={...job};
 try {
  const response=await page.goto(job.base+job.route,{waitUntil:'domcontentloaded',timeout:30000});
  await page.waitForTimeout(1800);
  await page.addScriptTag({path:out+'/axe.min.js'});
  Object.assign(result,{status:response.status(),url:page.url(),title:await page.title(),errors});
  result.axe=await page.evaluate(async()=>{const r=await axe.run(document,{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21a','wcag21aa','wcag22aa','best-practice']}});return {version:r.testEngine.version,violations:r.violations,passes:r.passes.map(x=>x.id),incomplete:r.incomplete.map(x=>({id:x.id,nodes:x.nodes.length}))};});
  result.desktop=await inspect(page);
  if(['/users/login','/users/register','/events','/finance','/governance/propose'].includes(job.route))await page.screenshot({path:out+'/'+job.kind+'-'+job.route.replaceAll('/','_')+'-'+job.theme+'.png',fullPage:true});
  await page.setViewportSize({width:320,height:900}); await page.waitForTimeout(250);
  result.narrow=await inspect(page);
  if(result.narrow.overflow>1)await page.screenshot({path:out+'/'+job.kind+'-'+job.route.replaceAll('/','_')+'-'+job.theme+'-320.png',fullPage:true});
  await page.addStyleTag({content:'* {line-height:1.5 !important;letter-spacing:0.12em !important;word-spacing:0.16em !important;} p {margin-bottom:2em !important;}'});
  result.textSpacing=await inspect(page);
 } catch(e){result.error=e.stack;}
 results.push(result); await fs.writeFile(out+'/public-results.json',JSON.stringify(results,null,2));
 console.log(JSON.stringify({route:job.route,theme:job.theme,title:result.title,error:result.error,violations:result.axe?.violations.map(v=>({id:v.id,n:v.nodes.length})),overflow:result.narrow?.overflow}));
 await context.close();
}
async function inspect(page){return page.evaluate(()=>{
 const visible=e=>{const r=e.getBoundingClientRect();const c=getComputedStyle(e);return r.width>0&&r.height>0&&c.visibility!=='hidden'&&c.display!=='none';};
 return {width:innerWidth,overflow:document.documentElement.scrollWidth-document.documentElement.clientWidth,lang:document.documentElement.lang,theme:document.documentElement.dataset.theme,
 headings:[...document.querySelectorAll('h1,h2,h3,h4')].filter(visible).map(e=>({tag:e.tagName,text:e.textContent.trim().slice(0,120)})),
 landmarks:[...document.querySelectorAll('main,nav,header,footer,[role="main"]')].map(e=>({tag:e.tagName,role:e.getAttribute('role'),label:e.getAttribute('aria-label')})),
 fields:[...document.querySelectorAll('input,select,textarea')].filter(visible).map(e=>({tag:e.tagName,type:e.type,id:e.id,name:e.name,label:[...e.labels||[]].map(l=>l.textContent.trim()).join(' '),ariaLabel:e.getAttribute('aria-label'),placeholder:e.getAttribute('placeholder'),autocomplete:e.autocomplete,invalid:e.getAttribute('aria-invalid'),describedby:e.getAttribute('aria-describedby')})),
 overflowElements:[...document.querySelectorAll('body *')].filter(visible).filter(e=>{const r=e.getBoundingClientRect();return r.right>innerWidth+1||r.left< -1;}).slice(0,16).map(e=>({tag:e.tagName,class:e.className,text:e.textContent.trim().slice(0,60),rect:{left:e.getBoundingClientRect().left,right:e.getBoundingClientRect().right}})),
 bodyExcerpt:document.querySelector('main')?.innerText.slice(0,1200)||document.body.innerText.slice(0,1200)};
 });}
await Promise.all([0,1,2].map(async()=>{while(jobs.length)await scan(jobs.shift());}));
await browser.close();
