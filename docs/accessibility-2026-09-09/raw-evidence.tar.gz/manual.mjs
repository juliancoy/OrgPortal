import { chromium } from '/home/julian/Documents/CodeCollective/portal/web/node_modules/playwright/index.mjs';
import { mockCommon,mockNativeChat } from './fixture-ui-ux-system.mjs';
import fs from 'node:fs/promises';
const out='/tmp/portal-accessibility-2026-09-09',browser=await chromium.launch({headless:true}),results={};
async function setup(auth=false,theme='light'){
 const context=await browser.newContext({viewport:{width:1280,height:900},colorScheme:theme});
 await context.addInitScript(t=>localStorage.setItem('orgportal.theme',t),theme);
 await context.route('**/*',route=>{const u=new URL(route.request().url());if(u.pathname.startsWith('/pidp/')||u.pathname.startsWith('/auth/')||u.pathname.startsWith('/api/'))return route.fulfill({status:401,contentType:'application/json',body:'{"detail":"Not signed in"}'});if(u.hostname!=='127.0.0.1')return route.abort();return route.continue();});
 const page=await context.newPage();if(auth)await mockCommon(page);return {context,page};
}
async function focus(page){return page.evaluate(()=>{const e=document.activeElement,r=e.getBoundingClientRect(),c=getComputedStyle(e);return {tag:e.tagName,id:e.id,text:(e.getAttribute('aria-label')||e.textContent).trim().slice(0,100),insideDialog:!!e.closest('[role="dialog"],[role="alertdialog"]'),outline:c.outline,shadow:c.boxShadow,rect:{x:r.x,y:r.y,width:r.width,height:r.height}};});}
async function ax(page){await page.addScriptTag({path:out+'/axe.min.js'});return page.evaluate(async()=>{const r=await axe.run();return {violations:r.violations,incomplete:r.incomplete.map(v=>({id:v.id,nodes:v.nodes.map(n=>({target:n.target,summary:n.failureSummary}))}))};});}
{
 const {context,page}=await setup();await page.route('**/auth/register',route=>route.fulfill({status:409,contentType:'application/json',body:'{"detail":"Account already exists"}'}));
 await page.goto('http://127.0.0.1:4197/users/register');await page.getByLabel('Email',{exact:true}).fill('audit@example.test');await page.locator('#pw').fill('Audit-only-123');await page.locator('.portal-auth-submit').focus();await page.keyboard.press('Enter');await page.getByRole('alertdialog').waitFor();
 const r={initialFocus:await focus(page),tabs:[]};for(let i=0;i<6;i++){await page.keyboard.press('Tab');r.tabs.push(await focus(page));}await page.keyboard.press('Escape');r.dialogAfterEscape=await page.getByRole('alertdialog').count();r.axe=await ax(page);await page.screenshot({path:out+'/registration-error.png'});results.registration=r;await fs.writeFile(out+'/manual-results.json',JSON.stringify(results,null,2));await context.close();
}
{
 const {context,page}=await setup(true,'dark');await page.goto('http://127.0.0.1:4197/profile');await page.getByRole('button',{name:'Replace photo',exact:true}).waitFor();await page.getByRole('button',{name:'Replace photo',exact:true}).focus();await page.locator('#profile-photo-upload').setInputFiles('/home/julian/Documents/CodeCollective/portal/web/public/codecollective_logo.png');await page.getByRole('dialog').waitFor();
 const r={initialFocus:await focus(page),tabs:[]};for(let i=0;i<5;i++){await page.keyboard.press('Tab');r.tabs.push(await focus(page));}r.axe=await ax(page);await page.keyboard.press('Escape');r.dialogAfterEscape=await page.getByRole('dialog').count();await page.screenshot({path:out+'/profile-photo-dialog-dark.png'});results.profileDialog=r;await fs.writeFile(out+'/manual-results.json',JSON.stringify(results,null,2));await context.close();
}
{
 const {context,page}=await setup(true);await mockNativeChat(page,{failSend:true});await page.goto('http://127.0.0.1:4197/chat/dm-1');await page.getByRole('textbox',{name:'Message',exact:true}).fill('Local accessibility audit');await page.getByRole('button',{name:'Send',exact:true}).click();await page.waitForTimeout(300);
 results.chat=await page.evaluate(()=>({errors:[...document.querySelectorAll('.portal-chat-error')].map(e=>({text:e.textContent,role:e.getAttribute('role'),live:e.getAttribute('aria-live'),liveAncestor:e.closest('[aria-live],[role="alert"],[role="status"],[role="log"]')?.outerHTML.slice(0,200)})),messageList:document.querySelector('.portal-chat-messages')?.outerHTML.slice(0,350),liveRegions:[...document.querySelectorAll('[aria-live],[role="log"],[role="status"],[role="alert"]')].map(e=>({role:e.getAttribute('role'),live:e.getAttribute('aria-live'),text:e.textContent.slice(0,120)}))}));await fs.writeFile(out+'/manual-results.json',JSON.stringify(results,null,2));await context.close();
}
{
 const context=await browser.newContext({viewport:{width:1280,height:900},colorScheme:'light'}),page=await context.newPage();await context.route('**/*',route=>['GET','HEAD','OPTIONS'].includes(route.request().method())?route.continue():route.abort());await page.goto('https://codecollective.us/p/users/login');await page.waitForTimeout(800);
 results.loginLinks=await page.locator('.portal-auth-card a').evaluateAll(es=>es.map(e=>({name:e.getAttribute('aria-label')||e.textContent,href:e.href})));
 await page.keyboard.press('Tab');results.firstTab=await focus(page);
 await page.emulateMedia({forcedColors:'active'});await page.getByLabel('Email',{exact:true}).focus();results.forcedColorsEmail=await focus(page);await page.screenshot({path:out+'/forced-colors-focus.png'});
 await page.emulateMedia({forcedColors:'none'});await page.setViewportSize({width:320,height:900});await page.getByLabel('Search organizations, events, and people').fill('code');await page.waitForTimeout(1300);await page.keyboard.press('ArrowDown');results.mobileSearch={axe:await ax(page),focus:await focus(page),overflow:await page.evaluate(()=>document.documentElement.scrollWidth-innerWidth)};await page.screenshot({path:out+'/mobile-search.png'});
 await page.setViewportSize({width:1280,height:900});await page.goto('https://codecollective.us/p/users/login');await page.getByRole('link',{name:'Departments',exact:true}).click();results.routeTransition={title:await page.title(),focus:await focus(page),skipCount:await page.locator('.skip-link').count()};
 await page.goto('https://codecollective.us/p/about');results.aboutDirectTitle=await page.title();await fs.writeFile(out+'/manual-results.json',JSON.stringify(results,null,2));await context.close();
}
await fs.writeFile(out+'/manual-results.json',JSON.stringify(results,null,2));console.log(JSON.stringify(results,(k,v)=>k==='axe'?{violations:v.violations.map(x=>({id:x.id,n:x.nodes.length}))}:v,2));await browser.close();
